export const MAX_PLAYERS = 8;
export const TURN_DURATION = 30; // in seconds