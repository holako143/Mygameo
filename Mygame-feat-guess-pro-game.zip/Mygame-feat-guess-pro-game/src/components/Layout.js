export default function Layout({ children }) {
  return <div className="min-h-screen bg-gray-900 text-white">{children}</div>;
}